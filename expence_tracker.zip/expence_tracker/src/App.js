import { Stack } from "react-bootstrap";
import Container from "react-bootstrap/Container";
import BudgetCard from "./components/BudgetCard";
import TotalBudgetCard from "./components/TotalBudgetCard";
import { useState } from "react";
import { UNCATEGORIZED_BUDGET_ID, useBudgets } from "./contexts/BudgetsContext";
import UncategorizedBudgetCard from "./components/UnCategorizedBudgetCard";
import ViewExpense from "./components/ViewExpense";
import AddExpense from "./components/AddExpense";
import AddBudget from "./components/AddBudget";
import EmptyCard from "./empty_cart.svg";
import { Button } from "@mantine/core";

function App() {
  const [showAddBudgetModal, setShowAddBudgetModal] = useState(false);
  const [showAddExpenseModal, setShowAddExpenseModal] = useState(false);
  const [viewExpensesModalBudgetId, setViewExpensesModalBudgetId] = useState();
  const [addExpenseModalBudgetId, setAddExpenseModalBudgetId] = useState();
  const [addExpenseModalBudgetAmount, setAddExpenseModalBudgetAmount] =
    useState();

  const { budgets, getBudgetExpenses } = useBudgets();

  function openAddExpenseModal(budgetId, amount) {
    setShowAddExpenseModal(true);
    setAddExpenseModalBudgetId(budgetId);
    setAddExpenseModalBudgetAmount(amount);
  }

  return (
    <>
      <Container className='my-4'>
        <div className='card px-3 py-3 shadow'>
          <div className='card-header'>
            <div className='card-title d-flex justify-content-between'>
              <div>
                <h2 className='me-auto'>Budgets</h2>
              </div>
              <Button
              className="mt-2"
                variant='light'
                onClick={() => setShowAddBudgetModal(true)}
              >
                Add Budget
              </Button>
            </div>
          </div>
          <div
            className='card-body'
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
              gap: "1rem",
              alignItems: "flex-start",
            }}
          >
            {budgets.length > 0 ? (
              <>
                {budgets?.map((budget) => {
                  const amount = getBudgetExpenses(budget?.id).reduce(
                    (total, expense) => total + expense.amount,
                    0
                  );
                  return (
                    <BudgetCard
                      key={budget.id}
                      name={budget.name}
                      amount={amount}
                      max={budget.max}
                      onAddExpenseClick={() =>
                        openAddExpenseModal(budget?.id, budget?.max)
                      }
                      onViewExpensesClick={() =>
                        setViewExpensesModalBudgetId(budget?.id)
                      }
                    />
                  );
                })}
              </>
            ) : (
              <div className='text-center'>
                <div className='fs-5 text-gray-600 fw-bold'>
                  No Records Found!
                </div>
                <img
                  src={EmptyCard}
                  alt='noRecordAvailable'
                  style={{ maxWidth: "100%", height: "auto" }}
                />
              </div>
            )}
            <UncategorizedBudgetCard
              onAddExpenseClick={openAddExpenseModal}
              onViewExpensesClick={() =>
                setViewExpensesModalBudgetId(UNCATEGORIZED_BUDGET_ID)
              }
            />
            <TotalBudgetCard />
          </div>
        </div>
      </Container>

      <AddBudget
        show={showAddBudgetModal}
        handleClose={() => setShowAddBudgetModal(false)}
      />
      <AddExpense
        show={showAddExpenseModal}
        defaultBudgetId={addExpenseModalBudgetId}
        defaultBudgetAmount={addExpenseModalBudgetAmount}
        handleClose={() => setShowAddExpenseModal(false)}
      />
      <ViewExpense
        budgetId={viewExpensesModalBudgetId}
        handleClose={() => setViewExpensesModalBudgetId()}
      />
    </>
  );
}

export default App;
