import { Button, Modal } from "@mantine/core";
import React, { useRef, useState } from "react";
import { Form } from "react-bootstrap";
import {
  UNCATEGORIZED_BUDGET_ID,
  useBudgets,
} from "../contexts/BudgetsContext";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";
import useLocalStorage from "../hooks/useLocalStorage";

const MySwal = withReactContent(Swal);

export default function AddExpense({
  show,
  handleClose,
  defaultBudgetId,
  defaultBudgetAmount,
}) {
  const descriptionRef = useRef();
  const amountRef = useRef();
  const budgetIdRef = useRef();

  const { addExpense, budgets } = useBudgets();
  const [errors, setErrors] = useState({});

  function handleSubmit(e) {
    e.preventDefault();

    const description = descriptionRef.current.value;
    const amount = parseFloat(amountRef.current.value);
    const budgetId = budgetIdRef.current.value;

    const newErrors = {};

    // Validate description
    if (!description) newErrors.description = "Please enter a Description.";

    // Validate amount
    if (isNaN(amount) || amount <= 0)
      newErrors.amount =
        "Please enter a Amount , Amount must be a positive number";
    else if (amount > defaultBudgetAmount) {
      MySwal.fire({
        title: "Error",
        text: `The entered amount (₹${amount.toFixed(
          2
        )}) exceeds the available budget (₹${defaultBudgetAmount.toFixed(
          2
        )}). Please select an amount within the available budget.`,
        icon: "error",
        confirmButtonText: "OK",
      });
      return;
    }

    if (!budgetId) newErrors.budgetId = "Please select a budget";

    if (Object?.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    addExpense({
      description,
      amount,
      budgetId,
    });

    MySwal.fire({
      title: "Expense Added",
      text: "Your expense has been added successfully!",
      icon: "success",
      confirmButtonText: "OK",
    });
    handleClose();
  }

  function handleInputChange(e) {
    const { name, value } = e.target;
    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
  }

  return (
    <>
      <Modal
        opened={show}
        onClose={() => null}
        withCloseButton={false}
        size='40rem'
        overlayProps={{
          backgroundOpacity: 0.55,
          blur: 3,
        }}
        transitionProps={{
          transition: "fade",
          duration: 400,
          timingFunction: "linear",
        }}
      >
        <Modal.Header className='d-flex justify-content-between border-bottom mb-4'>
          <Modal.Title>
            <div className='fw-bold fs-4'>New Expense</div>
          </Modal.Title>
          <button className='btn btn-icon btn-sm btn-active-icon-danger'>
            <i
              className='fa-solid fa-xmark fs-5'
              onClick={() => {
                handleClose();
                setErrors({});
              }}
            />
          </button>
        </Modal.Header>
        <Modal.Body className='border-bottom mb-2'>
          <Form.Group className='mb-3' controlId='description'>
            <Form.Label>Description</Form.Label>
            <Form.Control
              name='description'
              ref={descriptionRef}
              type='text'
              autoComplete='off'
              isInvalid={!!errors.description}
              placeholder='Enter expense description'
              onChange={handleInputChange}
            />
            <Form.Control.Feedback type='invalid'>
              {errors.description}
            </Form.Control.Feedback>
          </Form.Group>
          <Form.Group className='mb-3' controlId='amount'>
            <Form.Label>Amount</Form.Label>
            <Form.Control
              name='amount'
              ref={amountRef}
              type='number'
              isInvalid={!!errors.amount}
              min={0}
              step={0.01}
              placeholder='Enter amount'
              onChange={handleInputChange}
            />
            <Form.Control.Feedback type='invalid'>
              {errors.amount}
            </Form.Control.Feedback>
          </Form.Group>
          <Form.Group className='mb-3' controlId='budgetId'>
            <Form.Label>Budget</Form.Label>
            <Form.Select
              name='budgetId'
              defaultValue={defaultBudgetId}
              ref={budgetIdRef}
              isInvalid={!!errors.budgetId}
              onChange={handleInputChange}
            >
              <option id={UNCATEGORIZED_BUDGET_ID}>Uncategorized</option>
              {budgets?.map((budget) => (
                <option key={budget?.id} value={budget?.id}>
                  {budget?.name}
                </option>
              ))}
            </Form.Select>
            <Form.Control.Feedback type='invalid'>
              {errors.budgetId}
            </Form.Control.Feedback>
          </Form.Group>
        </Modal.Body>
        <div className='d-flex justify-content-end'>
          <Button variant='primary' type='submit' onClick={handleSubmit}>
            Add Expense
          </Button>
        </div>
      </Modal>
    </>
  );
}
