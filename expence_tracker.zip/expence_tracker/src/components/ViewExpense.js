import { Stack } from "react-bootstrap";
import {
  UNCATEGORIZED_BUDGET_ID,
  useBudgets,
} from "../contexts/BudgetsContext";
import { currencyFormatter } from "../utils";
import { Button, Modal } from "@mantine/core";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";

const MySwal = withReactContent(Swal);

export default function ViewExpense({ budgetId, handleClose }) {
  const { getBudgetExpenses, budgets, deleteBudget, deleteExpense } =
    useBudgets();

  const expenses = getBudgetExpenses(budgetId);
  const budget =
    UNCATEGORIZED_BUDGET_ID === budgetId
      ? { name: "Uncategorized", id: UNCATEGORIZED_BUDGET_ID }
      : budgets.find((b) => b.id === budgetId);

  const handleDeleteExpense = (expense) => {
    MySwal.fire({
      title: "Are you sure?",
      text: "Do you want to delete this expense?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        deleteExpense(expense);
        handleClose();
        Swal.fire("Deleted!", "Your expense has been deleted.", "success");
      }
    });
  };

  const handleDeleteBudget = () => {
    MySwal.fire({
      title: "Are you sure?",
      text: "Do you want to delete this budget?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        deleteBudget(budget);
        handleClose();
        Swal.fire("Deleted!", "Your budget has been deleted.", "success");
      }
    });
  };

  return (
    <Modal
      opened={budgetId != null}
      onClose={handleClose}
      withCloseButton={false}
      size='40rem'
      overlayProps={{
        backgroundOpacity: 0.55,
        blur: 3,
      }}
      transitionProps={{
        transition: "fade",
        duration: 400,
        timingFunction: "linear",
      }}
    >
      <Modal.Header className='d-flex justify-content-between border-bottom mb-3'>
        <Modal.Title>
          <div className='fw-bold fs-4'>
            <div>Expenses - {budget?.name}</div>
          </div>
        </Modal.Title>
        {budgetId !== UNCATEGORIZED_BUDGET_ID && (
          <Button onClick={handleDeleteBudget} variant='outline-danger'>
            Delete Budget
          </Button>
        )}
        <button
          className='btn btn-icon btn-sm btn-active-icon-danger'
          onClick={handleClose}
        >
          <i className='fa-solid fa-xmark fs-5' />
        </button>
      </Modal.Header>
      <Modal.Body>
        <Stack direction='vertical' gap='3'>
          {expenses?.map((expense) => (
            <Stack direction='horizontal' gap='2' key={expense.id}>
              {/* <input type='checkbox' name='' id='' className='Form-control ' /> */}
              <div className='me-auto fs-4'>{expense.description}</div>
              <div className='fs-5'>
                {currencyFormatter?.format(expense.amount)}
              </div>
              <Button
                onClick={() => handleDeleteExpense(expense)}
                variant='transparent'
                size=''
              >
                <i className='fa-solid fa-xmark'></i>
              </Button>
            </Stack>
          ))}
        </Stack>
      </Modal.Body>
    </Modal>
  );
}
