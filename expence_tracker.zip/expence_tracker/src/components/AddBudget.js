import { Button, Modal } from "@mantine/core";
import React, { useRef, useState } from "react";
import { Form } from "react-bootstrap";
import { useBudgets } from "../contexts/BudgetsContext";
import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";

const MySwal = withReactContent(Swal);

export default function AddBudget({ show, handleClose }) {
  const nameRef = useRef();

  const maxRef = useRef();

  const [errors, setErrors] = useState({});

  const { addBudget } = useBudgets();

  function handleSubmit(e) {
    e.preventDefault();

    const name = nameRef.current.value;
    const max = parseFloat(maxRef.current.value);

    const newErrors = {};
    if (!name) newErrors.name = "Please enter a Budget Name.";
    if (isNaN(max) || max <= 0)
      newErrors.max =
        "Please enter a Maximum Spending , Maximum Spending must be a positive number.";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    addBudget({
      name,
      max,
    });

    MySwal.fire({
      title: "Expense Added",
      text: "Your budget has been added successfully!",
      icon: "success",
      confirmButtonText: "OK",
    });
    handleClose();
  }

  function handleInputChange(e) {
    const { name, value } = e.target;
    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
  }
  return (
    <>
      <Modal
        opened={show}
        onClose={() => null}
        withCloseButton={false}
        size='40rem'
        overlayProps={{
          backgroundOpacity: 0.55,
          blur: 3,
        }}
        transitionProps={{
          transition: "fade",
          duration: 400,
          timingFunction: "linear",
        }}
      >
        {/* <Form onSubmit={handleSubmit}> */}
        <Modal.Header className='d-flex justify-content-between border-bottom mb-3'>
          <Modal.Title>
            <div className='fw-bold fs-4'>
              <div>New Budget</div>
            </div>
          </Modal.Title>
          <button
            className='btn btn-icon btn-sm btn-active-icon-danger'
            onClick={() => {
              handleClose();
              setErrors({});
            }}
          >
            <i className='fa-solid fa-xmark fs-5' />
          </button>
        </Modal.Header>
        <Modal.Body className='border-bottom mb-2'>
          <Form.Group className='mb-3' controlId='name'>
            <Form.Label>Name</Form.Label>
            <Form.Control
              name='name'
              ref={nameRef}
              type='text'
              isInvalid={!!errors.name}
              required
              autoComplete='off'
              placeholder='Enter budget name'
              onChange={handleInputChange}
            />
            <Form.Control.Feedback type='invalid'>
              {errors.name}
            </Form.Control.Feedback>
          </Form.Group>
          <Form.Group className='mb-3' controlId='max'>
            <Form.Label>Maximum Spending</Form.Label>
            <Form.Control
              name='max'
              ref={maxRef}
              type='number'
              isInvalid={!!errors.max}
              min={0}
              step={0.01}
              placeholder='Enter maximum spending'
              onChange={handleInputChange}
            />
            <Form.Control.Feedback type='invalid'>
              {errors.max}
            </Form.Control.Feedback>
          </Form.Group>
        </Modal.Body>
        <div className='d-flex justify-content-end'>
          <Button variant='primary' type='submit' onClick={handleSubmit}>
            Add Budget
          </Button>
        </div>
        {/* </Form> */}
      </Modal>
    </>
  );
}
